# BurnPlan AI V3.1.4

This release adds a Simple Smoke Screening workflow to the current Streamlit app.

## New features
- Opens the Simple Smoke Screening Tool in a new browser tab.
- Records whether screening was completed.
- Records screening result: no targets, secondary-zone targets, or critical-zone targets.
- Saves smoke screening notes.
- Accepts a PDF or image screenshot/map upload.
- Preserves the smoke-screen attachment inside the editable `.burnplan` project file.
- Restores the smoke-screen fields and attachment when the complete project is uploaded later.
- Includes smoke-screen completion, result, notes, and attachment filename in the PDF.

## Update Streamlit
Upload all files from this folder to the root of the GitHub repository, replace the existing files, commit, and reboot the app. Main file path remains `app.py`.
